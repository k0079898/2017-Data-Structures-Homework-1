#ifndef _FUNCTION_H_
#define _FUNCTION_H_

#include <string>

class Parenthesis {
public:
    Parenthesis(){};
    ~Parenthesis(){};
    virtual void isValid(std::string s){};
};
class Implement;

#endif

